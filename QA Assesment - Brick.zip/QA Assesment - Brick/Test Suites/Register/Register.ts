<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Register</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>181894ff-f8b5-4be2-a6be-df956a84197b</testSuiteGuid>
   <testCaseLink>
      <guid>f952059a-08a5-4a9f-bd54-92aa73062de1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register success</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d7dcbdfd-35ec-4bd5-af84-a7f24b7abefe</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register success - Optional field empty</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b28ab240-10b3-49a1-b10c-d8e26f4706a3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register failed - All fields empty</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>aa132eb8-b9c5-4c92-9967-cf75ca329cc6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register failed - Password does not meet requirement</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3c79f496-146d-4cfd-8e63-a67f65572153</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register failed - Phone number is empty</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5ba02ebb-e1e5-4719-b4d8-979992629215</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register failed - Password does not match</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c62e8507-b024-4f49-89f1-5aa71001f959</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register failed - Phone number already exist</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>120994cf-134a-41a9-8965-732ff607db22</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register failed - Email already exist</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a5881ca4-cf31-4eec-a50d-7d2e144076dc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register failed - Invalid email address</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8bf36211-bc96-4504-b0e4-d82e0ea93c22</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register failed - Phone number less than 9 digits</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8abda8f9-2f7f-46af-a444-c540ed19c1c3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register failed - Phone number more than 15 digits</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
